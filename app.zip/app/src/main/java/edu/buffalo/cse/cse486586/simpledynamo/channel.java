package edu.buffalo.cse.cse486586.simpledynamo;

/**
 * Created by fengguotian on 5/5/16.
 */
public class channel {
}
